<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Register - SB Admin</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <form action="Login.php" method="POST">
                                    <div class="card-header">
                                        <h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-3">
                                                    <input class="form-control" name="fn" id="inputFirstName"
                                                        type="text" placeholder="Enter your first name" />
                                                    <label for="inputFirstName">First name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="ln" id="inputLastName" type="text"
                                                        placeholder="Enter your last name" />
                                                    <label for="inputLastName">Last name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="age" id="inputLastName"
                                                        type="text" placeholder="Enter your last name" />
                                                    <label for="inputLastName">What is your age?</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 d-flex flex-row gap-4 align-items-center">
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="gender" id="gender_0" type="radio"
                                                        class="custom-control-input " required="required"
                                                        value="Laki-laki">
                                                    <label for="gender_0" class="custom-control-label">Laki-laki</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="gender" id="gender_1" type="radio"
                                                        class="custom-control-input" value="Perempuan">
                                                    <label for="gender_1" class="custom-control-label">Perempuan</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputEmail" name="email" type="email"
                                                placeholder="name@example.com" />
                                            <label for="inputEmail">Email address</label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0 d-flex align-items-center">
                                                    <select class="form-select form-floating mb-3 " name="agama"
                                                        aria-label="Default select example col-md-6">
                                                        <option value="">Agama</option>
                                                        <option value="Islam">Islam</option>
                                                        <option value="Kristen">Kristen</option>
                                                        <option value="Hindu">Hindu</option>
                                                        <option value="Budha">Budha</option>
                                                        <option value="Katolik">katolik</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0 ">
                                                    <select class="form-select form-floating mb-3" name="pendidikan"
                                                        aria-label="Default select example col-md-6">
                                                        <option selected>Jenjang Pendidikan</option>
                                                        <option value="S1">S1</option>
                                                        <option value="S2">S2</option>
                                                        <option value="S3">S3</option>
                                                        <option value="SMK">SMK</option>
                                                        <option value="SMP">SMP</option>
                                                        <option value="SD">SD</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="kota" name="kota" type="text"
                                                        placeholder="Create a password" />
                                                    <label for="kota">Nama Kota</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="provinsi" name="provinsi" type="text"
                                                        placeholder="Confirm password" />
                                                    <label for="provinsi">Provinsi</label>
                                                </div>
                                            </div>
                                            <div class="card-header">
                                                <h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3>
                                            </div>
                                            <P>Periksa Ketentuan Yang Berlaku Untuk Anda Atau Aggota Kerabat Dekat Anda
                                                :</P>
                                            <div class="d-flex flex-row gap-4 align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="penyakit[]" type="checkbox"
                                                        id="asma" value="Asma">
                                                    <label class="form-check-label" for="asma">Asma</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="penyakit[]" type="checkbox"
                                                        id="jantung" value="Penyakit Jantung">
                                                    <label class="form-check-label" for="jantung">Penyakit
                                                        Jantung</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="penyakit[]" type="checkbox"
                                                        id="kangker" value="Kangker">
                                                    <label class="form-check-label" for="kangker">Kangker</label>
                                                </div>
                                                <div class="form-check form-check-inline mt-4">
                                                    <input class="form-check-input " name="penyakit[]" type="checkbox"
                                                        id="diabetes" value="Diabetes">
                                                    <label class="form-check-label" for="diabetes">Diabetes</label>
                                                    <br><br>
                                                </div>
                                            </div>
                                            <P>Periksa gejala yang anda alami saat ini :</P>
                                            <div class="d-flex flex-row gap-4 align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="gejala[]" type="checkbox"
                                                        id="dada" value="Sakit Dada">
                                                    <label class="form-check-label" for="dada">Sakit
                                                        Dada</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="gejala[]" type="checkbox"
                                                        id="kardiovaskular" value="Kardiovaskular">
                                                    <label class="form-check-label"
                                                        for="kardiovaskular">Kardiovaskular</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" name="gejala[]" type="checkbox"
                                                        id="pernafasan" value="Pernafasan">
                                                    <label class="form-check-label" for="pernafasan">Pernafasan</label>
                                                </div>
                                                <div class="form-check form-check-inline mt-4">
                                                    <input class="form-check-input" name="gejala[]" type="checkbox"
                                                        id="penambahan" value="Penambahan BB">
                                                    <label class="form-check-label" for="penambahan">Penambahan
                                                        BB</label>
                                                    <br><br>
                                                </div>
                                            </div>
                                            <p>Apakah saat ini Anda sedang Mengonsumsi obat?</p>
                                            <div class="d-flex flex-row gap-4 align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="or" id="ya"
                                                        value="Ya">
                                                    <label class="form-check-label" for="ya">Ya</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="or" id="tidak"
                                                        value="Tidak">
                                                    <label class="form-check-label" for="tidak">Tidak</label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Silahkan List Yang lain :</p>
                                        <div class="input-group">
                                            <textarea class="form-control" name="teks"
                                                aria-label="With textarea"></textarea>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid"><input class="btn btn-primary btn-block"
                                                    type="submit"></input></div>
                                        </div>
                                    </div>
                                    <div class="card-header">
                                        <h3 class="text-center font-weight-light my-4">Tetap jaga kesehatan mu sob...</h3>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>
    </div>
    <br>
    <br>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>